# @fishmeet/rn-sdk

FishMeet React Native SDK — RN binding of `@fishmeet/core` with full platform injection (AsyncStorage-backed session + settings storage, timer, notification center, packaged notification sounds, device enumeration, AudioSession lifecycle) and a built-in meeting UI layer, shipped with a config plugin that collects the non-customizable LiveKit Expo setup.

- Source package (development): `packages/rn-sdk` in the `fishmeetV2` repo, entry `src/index.ts` (source-distributed, same model as `@fishmeet/core`).
- Release artifact: `fishmeet-rn-sdk-{version}.tgz`, published to the `release/fishmeet-rn-sdk` branch of the private `gracetech-services/gt-jitsisdk` repo. `@fishmeet/core` and `lodash-es` / `text-encoding` are **inlined** into `build/index.js` at build time — hosts do not install core.
- Runtime peers (host-provided): `expo >= 56`, `react-native >= 0.85`, `react >= 18 || >= 19`, `livekit-client ^2.21.0`, `@livekit/react-native ^2.12.0 || ^3.1.0`, `@livekit/react-native-webrtc ^144.0.0 || ^150.0.0`, `@livekit/components-react ^2.9.17`, `react-native-safe-area-context ^5.7.0`, `react-native-svg ~15.15.4 || ~15.16.0`, `expo-blur ~56.0.4 || ~57.0.0 || ~58.0.0`, `expo-audio ~56.0.13 || ~57.0.0 || ~58.0.0`, `expo-keep-awake ~56.0.3 || ~57.0.0 || ~58.0.0`, `axios ^1.20.0`.
- `@livekit/react-native` and `@livekit/react-native-webrtc` are **paired**: `2.12.x` needs WebRTC `^144`, `3.1.x` needs WebRTC `^150`. Mixing them crashes on iOS at runtime (3.x calls the five-argument `willEnableEngine`), so pick one pair for the whole host app.
- Tested baseline: **Expo SDK 58** (React Native 0.88, React 19.3.0). SDK 56 / 57 are supported by peer range and API audit only — not runtime-tested. On an **Expo 58 host, Android builds require `@livekit/react-native@^3.1.0`**; 2.x fails Gradle configuration on AGP 9's built-in Kotlin.

## 1. Install

```bash
yarn add "https://raw.githubusercontent.com/gracetech-services/gt-jitsisdk/release/fishmeet-rn-sdk/fishmeet-rn-sdk-0.5.0.tgz"
yarn add react-native-svg@~15.15.4 expo-blur@~56.0.4 expo-audio@~56.0.13 @livekit/components-react@^2.9.17
```

> On an **Expo 57 host**, use `expo-blur@~57.0.0 expo-audio@~57.0.0`; on an **Expo 58 host**, use `expo-blur@~58.0.5 expo-audio@~58.0.10 expo-keep-awake@~58.0.3 react-native-svg@15.16.0` plus `@livekit/react-native@^3.1.0` and `@livekit/react-native-webrtc@^150.1.1`. Always match the versions of the host's Expo SDK `bundledNativeModules` — the SDK accepts all three SDK lines via its peer ranges; the host must install these packages itself (they are peers, not dependencies).

> The gt-jitsisdk repository is **private** — fetching the raw URL requires GitHub credentials on the machine installing the package (a fine-grained PAT with read access to that repo, wired into git's credential helper, e.g. via `gh auth login` or an existing `.netrc` / credential store). Match whatever convention your host project already uses for private GitHub tarball dependencies.
>
> `react-native-svg` is a **native module** — after adding it, re-run the native build (`npx expo run:ios` / `run:android`). The M2 UI components render icons via inline SVG strings (`SvgXml`), so no metro transformer configuration is required.
>
> `expo-blur` is also a **native module** (re-run the native build after adding it). `VideoTile` fills gallery/filmstrip camera tiles with `cover`, falling back to `contain` for portrait cameras and screen shares (jitsi's tile rule); the stage is always `contain` and is the only context rendering the blurred backdrop (iOS only — Android letterboxes onto the container color, because the WebRTC `SurfaceViewRenderer` is composited outside the view tree and cannot be captured by any view-level blur).
>
> `expo-audio` is a **native module** too (re-run the native build after adding it) — it plays the packaged notification sounds (`participantJoined` / `participantLeft` / `raiseHand`).

> After install the package prints a short setup pointer plus a compatibility summary of the versions your app actually has (postinstall hook). It flags the combinations peer ranges cannot express — `@livekit/react-native` 2.12 ↔ WebRTC 144 vs 3.1 ↔ 150, the Expo 58 Android floor, and Expo module packages that do not follow the host SDK line — as `WARNINGS`. npm / yarn run it automatically; **pnpm 10+** blocks dependency lifecycle scripts by default — in that case follow §2 below manually and review the peers above instead (the setup action is the same: declare the plugin and re-run the native build).

## 2. app.json — declare the SDK plugin

The SDK's config plugin combines `@livekit/react-native-expo-plugin` + `@config-plugins/react-native-webrtc` **plus the FishMeet native entries** — the Android PiP manifest flag, the MainActivity `onUserLeaveHint` / `onPictureInPictureModeChanged` overrides, the R8 `-dontwarn` rule for the WebRTC JNI stub (release builds fail `minifyReleaseWithR8` without it), and the iOS `UIBackgroundModes: audio` entry — so hosts need **no extra plugin declarations and no hand-edited native files**:

```json
{
  "expo": {
    "plugins": ["@fishmeet/rn-sdk"]
  }
}
```

Native setup (WebRTC globals, audio/camera permissions, the PiP + background-audio entries above) is applied during prebuild. Re-run `npx expo prebuild` (or `npx expo run:ios` / `run:android`) after adding the plugin. If the checked-in `ios/` directory predates the SDK version that added an entry, add it once by hand (`UIBackgroundModes` → `["audio"]`) or re-run `prebuild --clean` — whichever fits your workflow.

## 3. Usage — one-component integration

Mount `<FishMeet />` and you are done — it absorbs the whole host-side glue:

- **Bootstrap** (idempotent, done in the component render/effect): WebRTC globals (`registerGlobals` + Hermes `TextDecoder`/`Event` polyfills), the videoCall audio session configuration, and preloading of both storage mirrors (settings + session) behind a brief Loading state.
- **Provider tree**: mounts `FishMeetProvider` (which in turn provides the slices, settings/notification/UX stores and notification sounds).
- **View switch**: built-in `PreJoin` form ↔ full meeting room (`LiveKitRoom` + `MeetingRoom`), including the zombie-connection guards (`key={credentials.roomName}` remount, `connState === 'failed'` fallback).
- **Identity derivation**: same display name reuses the identity, a new one gets a random suffix (web `PreJoinPage` semantics; kept in memory so the form keeps its values after hangup).

```tsx
import { FishMeet } from '@fishmeet/rn-sdk';

export default function App() {
  return <FishMeet serverUrl="https://your-orchestrator-host" />;
}
```

Props:

| Prop                      | Type                           | Default                     | Purpose                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| ------------------------- | ------------------------------ | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `serverUrl`               | `string`                       | `https://f1.alphaomega.top` | Orchestrator base URL. Must be a **full origin** (protocol + host + port) — RN has no same-origin concept, so an empty string is invalid. Applied via `configureOrchestrator`; a prop change re-targets subsequent joins.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| `mock`                    | `boolean`                      | `false`                     | Orchestrator mock mode (mock credentials, no network).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| `initialRoomName`         | `string`                       | —                           | Seeds the PreJoin room name field on first render; wins over the remembered last room (invite links pair it with `initialPasscode`).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| `initialDisplayName`      | `string`                       | —                           | Seeds the PreJoin display name field on first render.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| `initialPasscode`         | `string`                       | —                           | Seeds the PreJoin passcode field (web `?pwd=` / `?passcode=` parity).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| `ingressToken`            | `string`                       | —                           | Opaque meeting ingress token (web `?t=`). When set, auto-joins via `/api/v1/ingress` and PreJoin is **never rendered**. Every failure before the meeting connects — exchange rejection, 20s connect timeout, `connState === 'failed'` — lands on the SDK result screen with **Try again / Exit**, and Exit fires `onMeetingEnd`. Only an in-meeting fatal connection failure (`connState === 'failed'` after having connected) hangs up on its own and exits through the normal end-of-meeting pipeline (firing `onMeetingEnd`, "Meeting ended" placeholder). Passive disconnects (`connState === 'disconnected'`, e.g. network loss) deliberately stay recoverable: the meeting view remains with the Reconnect notification card, no auto-exit. |
| `requirePasscode`         | `boolean`                      | see note                    | Force passcode required. Default: required outside `__DEV__` (web PreJoinPage parity).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| `onJoinFailed`            | `(error: JoinFailure) => void` | —                           | Fired when a join attempt fails (PreJoin submit, ingress exchange), a connect attempt times out / fails, or a render crash is caught. `JoinFailure` extends `Error` (so `message` keeps working) and adds `phase` / `reason` / `retryable` / `terminal` / `cause` / `status` / `code` for telemetry and custom error UI. Do **not** unmount on this callback alone: unmounting follows `onMeetingEnd`, except when `terminal` is `true` (render crash).                                                                                                                                                                                                                                                                                           |
| `onMeetingEnd`            | `() => void`                   | —                           | Fired when an active meeting ends (hangup / meeting ended) so the host can unmount `<FishMeet />`. Also fired when the Android hardware back key is pressed outside a meeting (PreJoin / joining / failed connect) — with the callback set the key is consumed and reported as the user's leave request; without it the key passes through to the host's own back handling.                                                                                                                                                                                                                                                                                                                                                                       |
| `onEnterPictureInPicture` | `() => boolean \| undefined`   | —                           | Called before the system PiP is entered — by the in-meeting PiP toggle and by the Android hardware back key mid-meeting. Return `false` to keep the meeting in-app — e.g. to show your own floating window (see the example app): the toggle skips system PiP, the back key is consumed and nothing else happens. Return `true`/`undefined` to proceed with the system PiP. Not consulted when the app enters PiP by backgrounding. There is no exit callback: by the time PiP closes the app is already foreground.                                                                                                                                                                                                                              |
| `inPictureInPicture`      | `boolean`                      | `false`                     | Host-declared "the meeting is shown in a small window": renders the same stage-only compact view as the system PiP. Pair with returning `false` from `onEnterPictureInPicture` for a fully custom overlay.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| `keepAwake`               | `boolean`                      | `true`                      | Keeps the screen on while the meeting view is shown (system auto-lock disabled). The lock is released as soon as the meeting view unmounts (leave / end); iOS also releases it while the app is backgrounded and restores it on return.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |

There is **no server picker** in this mode — the server is fixed by `serverUrl` (unless `serverUrl` is omitted in `__DEV__`, which shows the picker and defaults to f1). After the fishmeet session JWT expires (server default 3h), a non-ingress host can have the user re-enter room + passcode; an ingress host must supply a fresh `ingressToken` — that mode has no re-enter path (PreJoin is never rendered).

### 3.1 Failure handling contract

The SDK closes its own failure loop; the host only implements `onMeetingEnd` (unmount / go back):

- **Before the meeting connects** — exchange rejection, the 20s connect watchdog, or `connState === 'failed'` without ever having connected — the SDK shows its result screen: `Try again` (reuses the live session, otherwise repeats the exchange / join) and `Exit` (runs the normal exit pipeline and fires `onMeetingEnd`). The host does not need to react to `onJoinFailed` to avoid a dead end.
- **After the meeting connected** — an ingress fatal failure hangs up and fires `onMeetingEnd`; the host just unmounts. The result screen's `Exit` follows the same pipeline.
- **Render crash** — the fallback page offers `Exit` when `onMeetingEnd` is set, and `onJoinFailed` reports `terminal: true` for hosts that want to recover on their own.

Retries stay user-triggered (core keeps its single silent reconnect). In ingress mode `Try again` reuses the same `ingressToken`, and BSF tickets expire after roughly 60 seconds — a retry past that can only fail again, so supply a fresh `ingressToken` by remounting `<FishMeet />` when you need a new attempt window.

## 4. Advanced: custom composition

Hosts who need custom UI compose the lower-level exports directly (`FishMeetProvider`, `PreJoin` — with the optional `serverUrls` and `showServerPicker` props —, `MeetingRoom`, `useRnMeetingBasisSlice`, `useAudioSession`, `ensureLiveKitGlobals`, …). The example below mirrors what `<FishMeet />` does internally:

```tsx
import {
  configureAudioSession,
  FishMeetProvider,
  hydrateAsyncStorageBacked,
  hydrateSessionStorage,
  MeetingRoom,
  PreJoin,
  useAudioSession,
  useRnMeetingBasisSlice,
} from '@fishmeet/rn-sdk';
import { LiveKitRoom } from '@livekit/react-native';
import { useState } from 'react';

function Meeting() {
  const { credentials, connState, room, connect, onConnected, onDisconnected, onError } = useRnMeetingBasisSlice();
  const [lastIdentity, setLastIdentity] = useState<null | { displayName: string; roomName: string; identity: string }>(
    null,
  );

  // Hooks must run unconditionally — start on mount, stop on unmount.
  useAudioSession(true);

  if (!credentials || connState === 'failed') {
    return (
      <PreJoin
        onJoin={async (roomName, displayName, passcode) => {
          // Same-name reuse + random suffix (web PreJoinPage semantics).
          const identity =
            lastIdentity?.identity && lastIdentity.displayName === displayName
              ? lastIdentity.identity
              : `${displayName.trim().toLowerCase().replace(/\s+/g, '')}-${Math.random().toString(36).slice(2, 8)}`;
          setLastIdentity({ displayName, roomName, identity });
          await connect({ identity, displayName, roomName, passcode });
        }}
        initialRoomName={lastIdentity?.roomName}
        initialDisplayName={lastIdentity?.displayName}
        requirePasscode={!__DEV__}
      />
    );
  }

  return (
    <LiveKitRoom
      key={credentials.roomName}
      room={room ?? undefined}
      token={credentials.token}
      serverUrl={credentials.url}
      connect
      audio
      video
      onConnected={onConnected}
      onDisconnected={onDisconnected}
      onError={onError}
    >
      <MeetingRoom />
    </LiveKitRoom>
  );
}

export default function App() {
  return (
    <FishMeetProvider>
      <Meeting />
    </FishMeetProvider>
  );
}
```

Notes:

- In this mode the entry file (or an equivalent early point) must call `ensureLiveKitGlobals()`, `configureAudioSession()` and the two `hydrate*()` functions yourself, plus `configureOrchestrator({ baseUrl })` — see git history of this README (≤ v0.7) for the per-step guide.
- `key={credentials.roomName}` forces a full remount on room switch (prevents stale-room zombie connections, same pattern as the web client).
- The built-in `PreJoin` server picker (enabled by default; the persisted choice lives under the AsyncStorage key `fishmeet:server`) applies only to this low-level mode — `<FishMeet />` never reads or writes that key.
- Session + settings persistence is backed by AsyncStorage: call `hydrateSessionStorage()` and `hydrateAsyncStorageBacked()` once at startup before mounting the providers so stores read synchronously from their in-memory mirrors. Device prefs persist under the `fishmeet:settings` key with the same JSON shape as the web client's localStorage.
- `useAudioSession(active)` starts/stops the native audio session in an idempotent pair; `configureAudioSession()` applies the videoCall configuration and must run before connecting.
- `MeetingRoom` consumes the SDK slices + UxStore plus two optional props (`onEnterPictureInPicture` / `inPictureInPicture`, forwarded from `<FishMeet />` — omit both for the built-in behavior). It renders the connection status overlay, a persistent `TopStatusBar` that occupies layout space (left PiP toggle, centered room indicator, right camera-flip / audio-output actions — the bar row is never hidden, same on mobile and desktop widths; the elapsed-time pill and breakout banners float over the video as a horizontal row right below the room name and fade with the touch auto-hide), gallery/stage views with the filmstrip, the notification center (bottom-left stack), the chat + participants panes (mobile fullscreen overlays / desktop drawers that shift the view area), and the six-button toolbox (mic / camera, reactions, view mode, participants, chat, hangup — hosts get the end-meeting popover) with touch auto-hide (14s, toolbox + floating pill/banners) and responsive layout (mobile <= 480pt).

### Built-in UI components

| Export                                                                                                                                                            | Purpose                                                                                                                                                                                                                                                                                                                                           |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `PreJoin`                                                                                                                                                         | Join form (roomName/displayName + "Mute microphone on join" / "Turn off camera on join" switches writing `useSettingStore`)                                                                                                                                                                                                                       |
| `MeetingRoom`                                                                                                                                                     | Full meeting view assembly (see above)                                                                                                                                                                                                                                                                                                            |
| `GalleryView` / `StageView` / `Filmstrip` / `VideoTile`                                                                                                           | Media views; grid layout uses core `computeGridLayout`, filmstrip has mobile overlay + desktop column variants                                                                                                                                                                                                                                    |
| `Toolbox` + `AudioMuteButton` / `VideoMuteButton` / `ReactionsButton` / `ViewModeToggleButton` / `ParticipantsToggleButton` / `ChatToggleButton` / `HangupButton` | Toolbar controls. `ReactionsButton` opens applause / love / raise hand; mic/camera are plain mute toggles (device selection lives in the top-right actions); `HangupButton` opens the host end-meeting popover                                                                                                                                    |
| `ReactionsButton` / `ChatToggleButton` / `ParticipantsToggleButton`                                                                                               | Standalone toolbox entries (`ReactionsButton` is also exported as `RaiseHandButton`; chat unread badge caps at '9+')                                                                                                                                                                                                                              |
| `ToolboxMorePanel` / `MoreToggleButton` + `TOOLBOX_BUTTONS` / `MOBILE_PRIORITY` / `getMobileToolboxLayout`                                                        | Mobile overflow system; registry + width-graded layout helper (jitsi thresholds 360→4 / 240→2 / 0→0)                                                                                                                                                                                                                                              |
| `HangupPopover`                                                                                                                                                   | Host end-meeting double choice ("End meeting for all" danger / "Leave meeting" ghost)                                                                                                                                                                                                                                                             |
| `PipToggleButton`                                                                                                                                                 | Left slot of the meeting top bar: collapses the meeting into the Android system PiP window (bare icon, no background; hidden when unsupported or already in PiP); accepts an optional `onRequestEnterPip` interceptor, forwarded from `<FishMeet />`'s `onEnterPictureInPicture`)                                                                 |
| `NotificationsHub` / `NotificationCard`                                                                                                                           | Bottom-left notification stack (appearance ribbon + icon mapping, actions, exit animation)                                                                                                                                                                                                                                                        |
| `ChatPane` / `ParticipantsPane`                                                                                                                                   | Feature panels: chat (merged consecutive messages, autoscroll near bottom only) and roster (search, raised-hands first, host ask-to-speak menu)                                                                                                                                                                                                   |
| `PaneMenu` / `PaneMenuItem` / `PaneMenuDivider` / `PaneMenuSectionLabel`                                                                                          | Anchored dropdown menu kit (fullscreen backdrop close)                                                                                                                                                                                                                                                                                            |
| `TopBarActions` + `AudioDevicePopover`                                                                                                                            | Camera-flip / audio-output buttons rendered in the meeting top bar's right slot; the audio popover lists the native `AudioSession.getAudioOutputs()` rows (iOS `default` → Phone, `force_speaker` → Speaker; Android per the reported speaker/earpiece/bluetooth/headset set)                                                                     |
| `RaisedHandIndicator` / `AudioMutedIndicator` / `ScreenShareIndicator`                                                                                            | Tile/row indicators (audio level bars, screen label)                                                                                                                                                                                                                                                                                              |
| `TopStatusBar` / `MeetingTimer`                                                                                                                                   | `TopStatusBar` is the in-layout meeting bar (PiP toggle / room indicator / camera + audio actions; the elapsed-time pill and breakout banners float right below the room name and follow the `controlsVisible` auto-hide, `createdAt` seconds preferred over `joinedAt`); `MeetingTimer` is the standalone floating timer for host-composed views |
| `BreakoutBanner`                                                                                                                                                  | Breakout participant banners: switching hint, closing countdown (>60s yellow / ≤60s red pulse / expired notice, core `formatCountdown`), host broadcast auto-dismiss (10s)                                                                                                                                                                        |
| `BreakoutRoomList`                                                                                                                                                | Participant-side breakout room list (rows `Name (count)`, Join pill, Leave button, search by room or member name) — embedded at the tail of `ParticipantsPane` with the "You are in X" hint above the search box                                                                                                                                  |
| `ConnectionStatusIndicator`                                                                                                                                       | Reconnecting / disconnected overlay                                                                                                                                                                                                                                                                                                               |
| `ConnectionQualityBadge`                                                                                                                                          | 3-bar signal indicator (hidden while quality is Unknown)                                                                                                                                                                                                                                                                                          |
| `FmIcon` (`IFmIconName` — 76 names, mirrors the web `ICON_MAP` roster)                                                                                            | Inline-SVG icons, generated from `packages/assets/icons` via `scripts/gen-rn-icons.mjs`                                                                                                                                                                                                                                                           |
| `FmButton` / `ToolboxButton`                                                                                                                                      | Base buttons (default/accent/danger/ghost pill; 48pt toolbox buttons)                                                                                                                                                                                                                                                                             |
| `theme`                                                                                                                                                           | RN theme mirroring the web client (colors/layout/breakpoint/brand/zIndex)                                                                                                                                                                                                                                                                         |
| `useRnResponsive` / `useRnAutoHide` / `useRnConnectionQuality`                                                                                                    | Layout breakpoint state, touch auto-hide, participant quality subscription                                                                                                                                                                                                                                                                        |

### Fine-grained slice hooks (new code MUST use these)

| Hook                     | Contents                                                                                                                            |
| ------------------------ | ----------------------------------------------------------------------------------------------------------------------------------- |
| `useRnMeetingBasisSlice` | credentials / connState / room / session + connect, switchRoom, reconnect, hangup, endMeeting, onConnected, onDisconnected, onError |
| `useRnParticipantsSlice` | roster + focusedIdentity + media state + speaking identities                                                                        |
| `useRnChatSlice`         | messages, send, unreadCount, isSending                                                                                              |
| `useRnDeviceSlice`       | devices, activeDeviceIds, canSwitchOutput, switchDevice, flipCamera, refreshDevices                                                 |
| `useRnRaiseHandSlice`    | localRaised, raisedIdentities/Set/Count, toggleRaiseHand, inviteToSpeak                                                             |
| `useRnReactionSlice`     | bursts (one in-flight applause/love per identity), sendReaction                                                                     |
| `useRnBreakoutSlice`     | phase, breakouts, myBreakoutId/AssignmentId, closesAt, joinBreakout, returnToMain, host actions                                     |

`useRnMeetingSlice` is kept as a legacy facade that composes every slice context (it re-renders on every slice update — same compatibility policy as the web `useMeetingStore`).

### Built-in stores

`useNotificationStore()` (queue model identical to web: push/dismiss/clear, MAX cap with sticky exemption, timers via `rnTimer`), `useSettingStore()` (device prefs + startWith flags + audioSettings, AsyncStorage-persisted), `useUxStore()` (viewMode, pinnedIdentity, filmstripCollapsed, chatPaneOpen, participantsPaneOpen, controlsVisible + touch auto-hide handlers, isMobile/orientation). All three hooks require the corresponding provider, which `FishMeetProvider` mounts.

### Sounds & devices

- `playNotificationSound('participantJoined' | 'participantLeft' | 'raiseHand')` plays the packaged wav assets (expo-audio) with the same frequency pairs as the web oscillator; it is wired into `notify`/`playSound` automatically through `FishMeetProvider`. Fails silently — sound is a progressive enhancement.
- `rnDeviceEnumerator.enumerateDevices()` enumerates mic/camera devices (RN returns only `videoinput`/`audioinput`; there is no `audiooutput` entry). `canSwitchAudioOutput()` returns `false` on RN — output switching is not served by core's `switchDevice` pipeline. The top-right audio-output button lists `AudioSession.getAudioOutputs()` and switches through `AudioSession.selectAudioOutput` (iOS: `'default'` → Default — no app override, system routing, selecting it only clears the speaker override; `'force_speaker'` → Speaker. Android: speaker / earpiece → Phone / bluetooth / headset as reported, each a real device switch); bluetooth/headset routing on iOS stays with the system. The native session has no current-route read-back, so the list marks the expected active row: the session's explicit pick, otherwise the platform default (iOS system route → `default`; Android AudioSwitch's preferred first-available: bluetooth > headset > speaker > earpiece).
- `useRnDeviceSlice().flipCamera()` flips the local camera by re-capturing with the opposite `facingMode` (`user` ↔ `environment`) and keeps the current resolution/frame-rate. The platform picks the default lens for the requested side, which is why the SDK never selects a camera `deviceId` for flipping (iOS exposes several lenses per side without a primary marker). With the camera off it only shows a "turn the camera on" hint.

## 5. Meeting keep-alive: Android PiP + iOS Now Playing

A meeting that survives backgrounding, per platform:

| Platform    | Behavior                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ----------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Android** | System **Picture-in-Picture**: a top-left toggle collapses the meeting into the PiP window; backgrounding the app mid-meeting (home gesture / app switch — `onUserLeaveHint`) enters PiP automatically. The PiP window keeps the stage view only (all chrome — toolbox, top bar, panes, notifications — is hidden; the user's view mode restores on exit). Auto-enter is armed only while a meeting is live: backgrounding from `PreJoin` or after hangup never opens PiP. Requires API 24+, the `FEATURE_PICTURE_IN_PICTURE` system feature, and is disabled on Android Go (low-RAM) devices — the toggle simply stays hidden there. From v0.11 the hardware **back key** is also handled by the SDK: mid-meeting it consults `onEnterPictureInPicture` then enters system PiP, hanging up when PiP is unavailable; outside a meeting it fires `onMeetingEnd`; the host small-window mode (`inPictureInPicture`) never intercepts it. |
| **iOS**     | No system PiP for custom WebRTC views; instead the SDK maintains a **Now Playing card** (lock screen / Control Center) with the meeting title and elapsed time while the meeting runs, plus background audio (`UIBackgroundModes: audio`, applied by the config plugin) so the session keeps running when backgrounded. The card is cleared automatically when the meeting ends.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |

Host-side notes:

- **Screen stays on** while the built-in meeting view is shown: the SDK disables system auto-lock (Android `FLAG_KEEP_SCREEN_ON`, iOS `isIdleTimerDisabled`, via `expo-keep-awake`) and releases the lock as soon as the meeting view unmounts, so leaving the meeting restores the device's normal sleep policy. No permission and no extra plugin configuration are involved. Hosts that prefer battery saving over a lit screen pass `keepAwake={false}`.

- **All native entries are plugin-applied** (§2): the Android `supportsPictureInPicture` manifest flag, the `MainActivity` `onUserLeaveHint` / `onPictureInPictureModeChanged` overrides (forwarded into the bundled `FishMeetSdk` Expo module), and the iOS background-audio plist entry. No hand-edited native files.
- **Host callback**: `onEnterPictureInPicture` fires on the toggle press and before the back-key-triggered PiP (see props table). The common custom flow — returning `false` and showing your own in-app floating window — is demonstrated in `example/App.tsx` (`FloatingMeeting`), combined with `inPictureInPicture` so the embedded meeting renders its PiP-compact view inside your window.
- There is deliberately **no exit-PiP callback**: once the PiP window closes, the app is already foreground again and the built-in UI restores itself.

## 6. Scope statements

### 6.1 Breakout: participant side only

The SDK is a **full-featured participant client**: joining/leaving breakout rooms (list + Join/Leave, wake-up and directed-move auto-switching via the data channel, closing countdown banners, broadcast display) all work out of the box. Breakout **creation and management** (creating groups, rename, moving participants, closing groups, sending broadcasts) has no UI entry in the SDK — it stays with the web host or a host app that drives the data layer (`useRnBreakoutSlice().host`, of type `IBreakoutHostActions`, remains exported but is not surfaced in the built-in UI).

### 6.2 Screen share: viewing only

- **Viewing**: remote screen shares render in stage/gallery views (with the "Screen" indicator) out of the box.
- **Publishing**: the toolbox has no screenshare entry — and not just as a hidden button: the button registry type (`IToolboxButtonKey`) has no `'screenshare'` key at all. Publishing from mobile requires host-side native setup (an iOS ReplayKit broadcast extension / an Android MediaProjection foreground service); the SDK ships neither. Hosts who need mobile publishing wire their own capture pipeline and publish via the LiveKit Room API.

## 7. Type resolution note

The released `build/index.d.ts` is a **self-contained bundle** generated with `rolldown-plugin-dts` (TypeScript 6 compatible): `@fishmeet/core` types are inlined, so hosts never need to resolve core (it ships as a private workspace package and is not installable). The only remaining external type imports are the declared peer packages (`react`, `react-native`, `@livekit/react-native`, `@livekit/components-react`, `react-native-svg`, `livekit-client`), which hosts already install — typechecking works with `skipLibCheck: false` (the tsc default) as well.

## 8. Rebuilding the package (repo maintainers)

From the `fishmeetV2-client` repo root:

```bash
yarn build rn-sdk          # assemble + pack -> dist/fishmeet-rn-sdk-0.5.0.tgz
yarn push rn-sdk --dry-run # preview the gt-jitsisdk publish
yarn push rn-sdk           # user-initiated publish to the release branch
```
