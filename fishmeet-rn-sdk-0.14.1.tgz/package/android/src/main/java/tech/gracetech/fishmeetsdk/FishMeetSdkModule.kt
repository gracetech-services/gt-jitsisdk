package tech.gracetech.fishmeetsdk

import android.app.Activity
import android.app.ActivityManager
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Rational
import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.lang.ref.WeakReference

class FishMeetSdkModule : Module() {
  companion object {
    // Armed only while meeting credentials exist (JS toggles it on the meeting
    // lifecycle); static so the MainActivity overrides can consult it without
    // a module lookup.
    @Volatile private var autoPipEnabled = false

    // The MainActivity overrides fire outside any module instance scope; PiP
    // events go out through the last created instance.
    private var moduleRef: WeakReference<FishMeetSdkModule>? = null

    // Mirrors the system PiP state so a JS (re)load that starts inside PiP can
    // query it synchronously — the enter event fired before any listener existed.
    @Volatile private var currentInPip = false

    @JvmStatic
    fun onUserLeaveHint(activity: Activity) {
      if (!autoPipEnabled || !isPipSupportedInternal(activity)) return
      enterPipInternal(activity)
    }

    @JvmStatic
    fun onPipModeChanged(activity: Activity, isInPip: Boolean) {
      currentInPip = isInPip
      moduleRef?.get()?.sendEvent("onPipModeChanged", mapOf("isInPip" to isInPip))
    }

    @JvmStatic
    fun isPipSupportedInternal(activity: Activity): Boolean {
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
      if (!activity.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return false
      // Android Go devices advertise the feature but must stay excluded
      // (jitsi parity): the system may not open a PiP window reliably there.
      val activityManager = activity.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      return activityManager?.isLowRamDevice != true
    }

    fun enterPipInternal(activity: Activity) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val params = PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
        activity.enterPictureInPictureMode(params)
      } else {
        @Suppress("DEPRECATION")
        activity.enterPictureInPictureMode()
      }
    }
  }

  override fun definition() = ModuleDefinition {
    Name("FishMeetSdk")
    Events("onPipModeChanged")

    OnCreate {
      moduleRef = WeakReference(this@FishMeetSdkModule)
    }

    // Manual entry (PiP toggle button). Rejects on unsupported devices; the
    // JS side catches and stays silent (the button is hidden there anyway).
    AsyncFunction("enterPip") { promise: Promise ->
      val activity = appContext.currentActivity
      if (activity == null || !isPipSupportedInternal(activity)) {
        promise.reject("ERR_PIP_UNSUPPORTED", "Picture-in-Picture is not supported on this device", null)
        return@AsyncFunction
      }
      try {
        enterPipInternal(activity)
        promise.resolve()
      } catch (e: Exception) {
        promise.reject("ERR_PIP_ENTER_FAILED", e.message, e)
      }
    }

    // Meeting lifecycle switch: armed while credentials exist, disarmed on
    // hangup/unmount so backgrounding from PreJoin never opens PiP.
    Function("setAutoPipEnabled") { enabled: Boolean ->
      autoPipEnabled = enabled
    }

    Function("isPipSupported") {
      val activity = appContext.currentActivity
      activity != null && isPipSupportedInternal(activity)
    }

    Function("isInPipMode") {
      currentInPip
    }
  }
}
