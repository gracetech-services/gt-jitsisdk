#!/usr/bin/env node

// Printed when a host installs the package (npm postinstall hook). The native
// setup itself is collected in the config plugin, so this is a pointer to the
// one required host action, not a manual TODO list.

const lines = [
  '',
  'fishmeet: @fishmeet/rn-sdk installed.',
  '',
  'Next steps:',
  '  1. Declare the plugin in app.json:',
  '',
  '       "plugins": ["@fishmeet/rn-sdk"]',
  '',
  '     The plugin applies every native entry automatically: the LiveKit/WebRTC',
  '     setup, the Android PiP manifest flag + MainActivity overrides, and the',
  '     iOS UIBackgroundModes audio entry.',
  '',
  '  2. Re-run the native build:  npx expo prebuild   (or expo run:ios / run:android)',
  '',
  '  3. Optional props on <FishMeet />:',
  '     - onEnterPictureInPicture: called on the PiP toggle press; return false to',
  '       keep the meeting in-app (e.g. your own floating window).',
  '     - inPictureInPicture: renders the PiP-compact meeting UI (stage only) for',
  '       host-driven small windows.',
  '',
  'Full guide: the README.md shipped with @fishmeet/rn-sdk.',
  '',
];

console.log(lines.join('\n'));
