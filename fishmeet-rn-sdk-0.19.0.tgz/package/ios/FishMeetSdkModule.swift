import ExpoModulesCore
import MediaPlayer

// iOS meeting keep-alive visibility: a Now Playing card (lock screen /
// Control Center) while the meeting runs in the background. The WebRTC audio
// session is not an AVPlayer, so the info dictionary is written directly.
// The card is published as a live stream (no seek bar / duration).
public class FishMeetSdkModule: Module {
  private var commandsRegistered = false

  public func definition() -> ModuleDefinition {
    Name("FishMeetSdk")

    Function("setNowPlaying") { (title: String, startedAtMs: Double) in
      let elapsed = max(0, Date().timeIntervalSince1970 - startedAtMs / 1000)
      DispatchQueue.main.async { [weak self] in
        self?.registerRemoteCommandsIfNeeded()
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
          MPMediaItemPropertyTitle: title,
          MPMediaItemPropertyArtist: "FishMeet",
          MPNowPlayingInfoPropertyElapsedPlaybackTime: elapsed,
          MPNowPlayingInfoPropertyPlaybackRate: 1.0,
          MPNowPlayingInfoPropertyIsLiveStream: true,
        ]
      }
    }

    Function("clearNowPlaying") {
      DispatchQueue.main.async {
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
      }
    }
  }

  // iOS only promotes an app to the Now Playing slot when it answers the
  // remote command server: with no handler registered the card is suppressed
  // even though nowPlayingInfo is set. The play/pause target is a deliberate
  // no-op that keeps the card visible; seeking and track switching stay
  // disabled because a meeting is live audio, not media playback.
  private func registerRemoteCommandsIfNeeded() {
    guard !commandsRegistered else { return }
    commandsRegistered = true

    let center = MPRemoteCommandCenter.shared()
    center.togglePlayPauseCommand.isEnabled = true
    center.togglePlayPauseCommand.addTarget { _ in MPRemoteCommandHandlerStatus.success }
    center.playCommand.isEnabled = false
    center.pauseCommand.isEnabled = false
    center.changePlaybackPositionCommand.isEnabled = false
    center.nextTrackCommand.isEnabled = false
    center.previousTrackCommand.isEnabled = false
    center.skipForwardCommand.isEnabled = false
    center.skipBackwardCommand.isEnabled = false
    center.changePlaybackRateCommand.isEnabled = false
  }
}
