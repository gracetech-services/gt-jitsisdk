# @fishmeet/rn-sdk

> **Version**: v0.8
> **Created**: 2026-09-14 16:43
> **Updated**: 2026-09-18 12:22
> **Key changes**: Session JWT auth parity with web — `initialPasscode` / `idigestToken` / `requirePasscode` props; PreJoin passcode field; join via `/api/v1/meetings/join` or iDigest ingress.

FishMeet React Native SDK — RN binding of `@fishmeet/core` with full platform injection (AsyncStorage-backed session + settings storage, timer, notification center, packaged notification sounds, device enumeration, AudioSession lifecycle) and a built-in meeting UI layer, shipped with a config plugin that collects the non-customizable LiveKit Expo setup.

- Source package (development): `packages/rn-sdk` in the `fishmeetV2` repo, entry `src/index.ts` (source-distributed, same model as `@fishmeet/core`).
- Release artifact: `fishmeet-rn-sdk-{version}.tgz`, published to the `release/fishmeet-rn-sdk` branch of the private `gracetech-services/gt-jitsisdk` repo. `@fishmeet/core` and `lodash-es` / `text-encoding` are **inlined** into `build/index.js` at build time — hosts do not install core.
- Runtime peers (host-provided): `expo >= 56`, `react-native >= 0.85`, `react >= 18 || >= 19`, `livekit-client ^2.21.0`, `@livekit/react-native ^2.12.0`, `@livekit/react-native-webrtc ^144.0.0`, `@livekit/components-react ^2.9.17`, `react-native-safe-area-context ^5.7.0`, `react-native-svg ~15.15.4`, `expo-blur ~56.0.4`, `axios ^1.20.0`.

## 1. Install

```bash
yarn add "https://raw.githubusercontent.com/gracetech-services/gt-jitsisdk/release/fishmeet-rn-sdk/fishmeet-rn-sdk-0.5.0.tgz"
yarn add react-native-svg@~15.15.4 expo-blur@~56.0.4 @livekit/components-react@^2.9.17
```

> The gt-jitsisdk repository is **private** — fetching the raw URL requires GitHub credentials on the machine installing the package (a fine-grained PAT with read access to that repo, wired into git's credential helper, e.g. via `gh auth login` or an existing `.netrc` / credential store). Match whatever convention your host project already uses for private GitHub tarball dependencies.
>
> `react-native-svg` is a **native module** — after adding it, re-run the native build (`npx expo run:ios` / `run:android`). The M2 UI components render icons via inline SVG strings (`SvgXml`), so no metro transformer configuration is required.
>
> `expo-blur` is also a **native module** (re-run the native build after adding it). `VideoTile` renders a blurred cover-fill video backdrop behind the contain-fit video on large tiles (web parity); Android uses the experimental `dimezisBlurView` method.

## 2. app.json — declare the SDK plugin

The SDK's config plugin combines `@livekit/react-native-expo-plugin` + `@config-plugins/react-native-webrtc`, so hosts need **no extra LiveKit plugin declarations**:

```json
{
  "expo": {
    "plugins": ["@fishmeet/rn-sdk"]
  }
}
```

Native setup (WebRTC globals, audio/camera permissions) is applied during prebuild. Re-run `npx expo prebuild` (or `npx expo run:ios` / `run:android`) after adding the plugin.

## 3. Usage — one-component integration

Mount `<FishMeet />` and you are done — it absorbs the whole host-side glue:

- **Bootstrap** (idempotent, done in the component render/effect): WebRTC globals (`registerGlobals` + Hermes `TextDecoder`/`Event` polyfills), the videoCall audio session configuration, and preloading of both storage mirrors (settings + session) behind a brief Loading state.
- **Provider tree**: mounts `FishMeetProvider` (which in turn provides the slices, settings/notification/UX stores and notification sounds).
- **View switch**: built-in `PreJoin` form ↔ full meeting room (`LiveKitRoom` + `MeetingRoom`), including the zombie-connection guards (`key={credentials.roomName}` remount, `connState === 'failed'` fallback).
- **Identity derivation**: same display name reuses the identity, a new one gets a random suffix (web `PreJoinPage` semantics; kept in memory so the form keeps its values after hangup).

```tsx
import { FishMeet } from '@fishmeet/rn-sdk';

export default function App() {
  return <FishMeet serverUrl="https://your-orchestrator-host" />;
}
```

Props:

| Prop                 | Type      | Default                     | Purpose                                                                                                                                                                                                                   |
| -------------------- | --------- | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `serverUrl`          | `string`  | `https://f1.alphaomega.top` | Orchestrator base URL. Must be a **full origin** (protocol + host + port) — RN has no same-origin concept, so an empty string is invalid. Applied via `configureOrchestrator`; a prop change re-targets subsequent joins. |
| `mock`               | `boolean` | `false`                     | Orchestrator mock mode (mock credentials, no network).                                                                                                                                                                    |
| `initialRoomName`    | `string`  | —                           | Seeds the PreJoin room name field on first render.                                                                                                                                                                        |
| `initialDisplayName` | `string`  | —                           | Seeds the PreJoin display name field on first render.                                                                                                                                                                     |
| `initialPasscode`    | `string`  | —                           | Seeds the PreJoin passcode field (web `?pwd=` / `?passcode=` parity).                                                                                                                                                     |
| `idigestToken`       | `string`  | —                           | iDigest meeting JWT (web `?t=`). When set, auto-joins via `/api/v1/ingress` and hides the passcode field.                                                                                                                  |
| `requirePasscode`    | `boolean` | see note                    | Force passcode required. Default: required outside `__DEV__` when no `idigestToken` (web PreJoinPage parity).                                                                                                             |

There is **no server picker** in this mode — the server is fixed by `serverUrl` (unless `serverUrl` is omitted in `__DEV__`, which shows the picker and defaults to f1). After the fishmeet session JWT expires (server default 3h), the host must supply a fresh `idigestToken` or have the user re-enter room + passcode.

## 4. Advanced: custom composition

Hosts who need custom UI compose the lower-level exports directly (`FishMeetProvider`, `PreJoin` — with the optional `serverUrls` and `showServerPicker` props —, `MeetingRoom`, `useRnMeetingBasisSlice`, `useAudioSession`, `ensureLiveKitGlobals`, …). The example below mirrors what `<FishMeet />` does internally:

```tsx
import {
  configureAudioSession,
  FishMeetProvider,
  hydrateAsyncStorageBacked,
  hydrateSessionStorage,
  MeetingRoom,
  PreJoin,
  useAudioSession,
  useRnMeetingBasisSlice,
} from '@fishmeet/rn-sdk';
import { LiveKitRoom } from '@livekit/react-native';
import { useState } from 'react';

function Meeting() {
  const { credentials, connState, room, connect, onConnected, onDisconnected, onError } = useRnMeetingBasisSlice();
  const [lastIdentity, setLastIdentity] = useState<null | { displayName: string; roomName: string; identity: string }>(
    null,
  );

  // Hooks must run unconditionally — start on mount, stop on unmount.
  useAudioSession(true);

  if (!credentials || connState === 'failed') {
    return (
      <PreJoin
        onJoin={async (roomName, displayName, passcode) => {
          // Same-name reuse + random suffix (web PreJoinPage semantics).
          const identity =
            lastIdentity?.identity && lastIdentity.displayName === displayName
              ? lastIdentity.identity
              : `${displayName.trim().toLowerCase().replace(/\s+/g, '')}-${Math.random().toString(36).slice(2, 8)}`;
          setLastIdentity({ displayName, roomName, identity });
          await connect({ identity, displayName, roomName, passcode });
        }}
        initialRoomName={lastIdentity?.roomName}
        initialDisplayName={lastIdentity?.displayName}
        requirePasscode={!__DEV__}
      />
    );
  }

  return (
    <LiveKitRoom
      key={credentials.roomName}
      room={room ?? undefined}
      token={credentials.token}
      serverUrl={credentials.url}
      connect
      audio
      video
      onConnected={onConnected}
      onDisconnected={onDisconnected}
      onError={onError}
    >
      <MeetingRoom />
    </LiveKitRoom>
  );
}

export default function App() {
  return (
    <FishMeetProvider>
      <Meeting />
    </FishMeetProvider>
  );
}
```

Notes:

- In this mode the entry file (or an equivalent early point) must call `ensureLiveKitGlobals()`, `configureAudioSession()` and the two `hydrate*()` functions yourself, plus `configureOrchestrator({ baseUrl })` — see git history of this README (≤ v0.7) for the per-step guide.
- `key={credentials.roomName}` forces a full remount on room switch (prevents stale-room zombie connections, same pattern as the web client).
- The built-in `PreJoin` server picker (enabled by default; the persisted choice lives under the AsyncStorage key `fishmeet:server`) applies only to this low-level mode — `<FishMeet />` never reads or writes that key.
- Session + settings persistence is backed by AsyncStorage: call `hydrateSessionStorage()` and `hydrateAsyncStorageBacked()` once at startup before mounting the providers so stores read synchronously from their in-memory mirrors. Device prefs persist under the `fishmeet:settings` key with the same JSON shape as the web client's localStorage.
- `useAudioSession(active)` starts/stops the native audio session in an idempotent pair; `configureAudioSession()` applies the videoCall configuration and must run before connecting.
- `MeetingRoom` consumes only the SDK slices + UxStore — no props. It renders the connection status overlay, the mobile `TopStatusBar` / desktop `MeetingTimer` timer, gallery/stage views with the filmstrip, the notification center (bottom-left stack), the chat + participants panes (mobile fullscreen overlays / desktop drawers that shift the view area), and the six-button toolbox (mic / camera with device-popover chevrons, raise hand, view mode, participants, chat, hangup — hosts get the end-meeting popover) with touch auto-hide (14s) and responsive layout (mobile <= 480pt).

### Built-in UI components

| Export                                                                                                                                                            | Purpose                                                                                                                                                                                                          |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `PreJoin`                                                                                                                                                         | Join form (roomName/displayName + "Mute microphone on join" / "Turn off camera on join" switches writing `useSettingStore`)                                                                                      |
| `MeetingRoom`                                                                                                                                                     | Full meeting view assembly (see above)                                                                                                                                                                           |
| `GalleryView` / `StageView` / `Filmstrip` / `VideoTile`                                                                                                           | Media views; grid layout uses core `computeGridLayout`, filmstrip has mobile overlay + desktop column variants                                                                                                   |
| `Toolbox` + `AudioMuteButton` / `VideoMuteButton` / `RaiseHandButton` / `ViewModeToggleButton` / `ParticipantsToggleButton` / `ChatToggleButton` / `HangupButton` | Toolbar controls. Multi-device buttons show a chevron opening the device popovers; `HangupButton` opens the host end-meeting popover                                                                             |
| `RaiseHandButton` / `ChatToggleButton` / `ParticipantsToggleButton`                                                                                               | Standalone toolbox entries (unread badge caps at '9+')                                                                                                                                                           |
| `ToolboxMorePanel` / `MoreToggleButton` + `TOOLBOX_BUTTONS` / `MOBILE_PRIORITY` / `getMobileToolboxLayout`                                                        | Mobile overflow system; registry + width-graded layout helper (jitsi thresholds 360→4 / 240→2 / 0→0)                                                                                                             |
| `HangupPopover`                                                                                                                                                   | Host end-meeting double choice ("End meeting for all" danger / "Leave meeting" ghost)                                                                                                                            |
| `NotificationsHub` / `NotificationCard`                                                                                                                           | Bottom-left notification stack (appearance ribbon + icon mapping, actions, exit animation)                                                                                                                       |
| `ChatPane` / `ParticipantsPane`                                                                                                                                   | Feature panels: chat (merged consecutive messages, autoscroll near bottom only) and roster (search, raised-hands first, host ask-to-speak menu)                                                                  |
| `PaneMenu` / `PaneMenuItem` / `PaneMenuDivider` / `PaneMenuSectionLabel`                                                                                          | Anchored dropdown menu kit (fullscreen backdrop close)                                                                                                                                                           |
| `ToolboxButtonPopoverTrigger` + `AudioDevicePopover` / `VideoDevicePopover`                                                                                       | Popover trigger for toolbox buttons (chevron + anchored panel) and device selection popovers (mic list + iOS `default`/`force_speaker` speaker rows; camera list)                                                |
| `RaisedHandIndicator` / `AudioMutedIndicator` / `ScreenShareIndicator`                                                                                            | Tile/row indicators (audio level bars, screen label)                                                                                                                                                             |
| `TopStatusBar` / `MeetingTimer`                                                                                                                                   | Elapsed-time display (`createdAt` seconds preferred, `joinedAt` fallback) — both embed `BreakoutBanner`                                                                                                          |
| `BreakoutBanner`                                                                                                                                                  | Breakout participant banners: switching hint, closing countdown (>60s yellow / ≤60s red pulse / expired notice, core `formatCountdown`), host broadcast auto-dismiss (10s)                                       |
| `BreakoutRoomList`                                                                                                                                                | Participant-side breakout room list (rows `Name (count)`, Join pill, Leave button, search by room or member name) — embedded at the tail of `ParticipantsPane` with the "You are in X" hint above the search box |
| `ConnectionStatusIndicator`                                                                                                                                       | Reconnecting / disconnected overlay                                                                                                                                                                              |
| `ConnectionQualityBadge`                                                                                                                                          | 3-bar signal indicator (hidden while quality is Unknown)                                                                                                                                                         |
| `FmIcon` (`IFmIconName` — 61 names, mirrors the web `ICON_MAP` roster)                                                                                            | Inline-SVG icons, generated from `packages/assets/icons` via `scripts/gen-rn-icons.mjs`                                                                                                                          |
| `FmButton` / `ToolboxButton`                                                                                                                                      | Base buttons (default/accent/danger/ghost pill; 48pt toolbox buttons)                                                                                                                                            |
| `theme`                                                                                                                                                           | RN theme mirroring the web client (colors/layout/breakpoint/brand/zIndex)                                                                                                                                        |
| `useRnResponsive` / `useRnAutoHide` / `useRnConnectionQuality`                                                                                                    | Layout breakpoint state, touch auto-hide, participant quality subscription                                                                                                                                       |

### Fine-grained slice hooks (new code MUST use these)

| Hook                     | Contents                                                                                                                            |
| ------------------------ | ----------------------------------------------------------------------------------------------------------------------------------- |
| `useRnMeetingBasisSlice` | credentials / connState / room / session + connect, switchRoom, reconnect, hangup, endMeeting, onConnected, onDisconnected, onError |
| `useRnParticipantsSlice` | roster + focusedIdentity + media state + speaking identities                                                                        |
| `useRnChatSlice`         | messages, send, unreadCount, isSending                                                                                              |
| `useRnDeviceSlice`       | devices, activeDeviceIds, canSwitchOutput, switchDevice, refreshDevices                                                             |
| `useRnRaiseHandSlice`    | localRaised, raisedIdentities/Set/Count, toggleRaiseHand, inviteToSpeak                                                             |
| `useRnBreakoutSlice`     | phase, breakouts, myBreakoutId/AssignmentId, closesAt, joinBreakout, returnToMain, host actions                                     |

`useRnMeetingSlice` is kept as a legacy facade that composes all six slices (it re-renders on every slice update — same compatibility policy as the web `useMeetingStore`).

### Built-in stores

`useNotificationStore()` (queue model identical to web: push/dismiss/clear, MAX cap with sticky exemption, timers via `rnTimer`), `useSettingStore()` (device prefs + startWith flags + audioSettings, AsyncStorage-persisted), `useUxStore()` (viewMode, pinnedIdentity, filmstripCollapsed, chatPaneOpen, participantsPaneOpen, controlsVisible + touch auto-hide handlers, isMobile/orientation). All three hooks require the corresponding provider, which `FishMeetProvider` mounts.

### Sounds & devices

- `playNotificationSound('participantJoined' | 'participantLeft' | 'raiseHand')` plays the packaged wav assets (expo-audio) with the same frequency pairs as the web oscillator; it is wired into `notify`/`playSound` automatically through `FishMeetProvider`. Fails silently — sound is a progressive enhancement.
- `rnDeviceEnumerator.enumerateDevices()` enumerates mic/camera devices (RN returns only `videoinput`/`audioinput`; there is no `audiooutput` entry). `canSwitchAudioOutput()` returns `false` on RN — output switching is not served by core's `switchDevice` pipeline; use `AudioSession.selectAudioOutput` from `@livekit/react-native` instead (iOS supports `'default'` / `'force_speaker'`; Android exposes `getAudioOutputs()`).

## 5. Scope statements

### 5.1 Breakout: participant side only (A22)

The SDK is a **full-featured participant client**: joining/leaving breakout rooms (list + Join/Leave, wake-up and directed-move auto-switching via the data channel, closing countdown banners, broadcast display) all work out of the box. Breakout **creation and management** (creating groups, rename, moving participants, closing groups, sending broadcasts) has no UI entry in the SDK — it stays with the web host or a host app that drives the data layer (`useRnBreakoutSlice().host`, of type `IBreakoutHostActions`, remains exported but is not surfaced in the built-in UI).

### 5.2 Screen share: viewing only (A23)

- **Viewing**: remote screen shares render in stage/gallery views (with the "Screen" indicator) out of the box.
- **Publishing**: the toolbox has no screenshare entry — and not just as a hidden button: the button registry type (`IToolboxButtonKey`) has no `'screenshare'` key at all. Publishing from mobile requires host-side native setup (an iOS ReplayKit broadcast extension / an Android MediaProjection foreground service); the SDK ships neither. Hosts who need mobile publishing wire their own capture pipeline and publish via the LiveKit Room API.

## 6. Type resolution note

The released `build/index.d.ts` is a **self-contained bundle** generated with `rolldown-plugin-dts` (TypeScript 6 compatible): `@fishmeet/core` types are inlined, so hosts never need to resolve core (it ships as a private workspace package and is not installable). The only remaining external type imports are the declared peer packages (`react`, `react-native`, `@livekit/react-native`, `@livekit/components-react`, `react-native-svg`, `livekit-client`), which hosts already install — typechecking works with `skipLibCheck: false` (the tsc default) as well.

## 7. Rebuilding the package (repo maintainers)

From the `fishmeetV2-client` repo root:

```bash
yarn build rn-sdk          # assemble + pack -> dist/fishmeet-rn-sdk-0.5.0.tgz
yarn push rn-sdk --dry-run # preview the gt-jitsisdk publish
yarn push rn-sdk           # user-initiated publish to the release branch
```
