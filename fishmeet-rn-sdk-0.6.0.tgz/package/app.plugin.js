// Expo config-plugin entry convention (plugin-resolver.ts): hosts referencing
// this package by name resolve app.plugin.* FIRST, before the main entry.
/* eslint-disable @typescript-eslint/no-require-imports -- CJS entry file by Expo convention */
module.exports = require('./plugin/build/index.js');
