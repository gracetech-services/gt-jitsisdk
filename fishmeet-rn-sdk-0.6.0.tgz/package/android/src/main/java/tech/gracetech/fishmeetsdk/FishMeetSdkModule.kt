package tech.gracetech.fishmeetsdk

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class FishMeetSdkModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("FishMeetSdk")
  }
}
