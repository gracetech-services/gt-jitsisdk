import ExpoModulesCore

public class FishMeetSdkModule: Module {
  public func definition() -> ModuleDefinition {
    Name("FishMeetSdk")
  }
}
