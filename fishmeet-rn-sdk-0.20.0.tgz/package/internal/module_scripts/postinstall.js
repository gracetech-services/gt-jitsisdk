#!/usr/bin/env node

// Printed when a host installs the package (npm postinstall hook). The native
// setup itself is collected in the config plugin, so the next-steps block is a
// pointer to the one required host action, not a manual TODO list.
//
// The version report exists because peer ranges cannot express the paired
// constraints (@livekit/react-native 2.12 <-> WebRTC 144, 3.1 <-> 150) or the
// Expo-58 Android floor. Those combinations install cleanly and only fail
// later, during the native build, so the check surfaces them at install time.
// Every detection path is best-effort: failures fall back to the static notes
// and never exit non-zero (a broken postinstall would break the host install).

const fs = require('fs');
const path = require('path');

// Peer ranges restated for the summary table; peerDependencies stay the
// authoritative declaration, this only renders them next to the real version.
const PACKAGES = [
  { name: 'expo', range: '>= 56' },
  { name: 'react-native', range: '>= 0.85' },
  { name: '@livekit/react-native', range: '^2.12.0 || ^3.1.0' },
  { name: '@livekit/react-native-webrtc', range: '^144.0.0 || ^150.0.0' },
];

// Bundled versions per SDK line, used by the "follows the host SDK" warnings.
const SDK_LINES = {
  56: { 'expo-blur': '~56.0.4', 'expo-audio': '~56.0.13', 'expo-keep-awake': '~56.0.3' },
  57: { 'expo-blur': '~57.0.0', 'expo-audio': '~57.0.0', 'expo-keep-awake': '~57.0.0' },
  58: { 'expo-blur': '~58.0.5', 'expo-audio': '~58.0.10', 'expo-keep-awake': '~58.0.3' },
};

// RN version each SDK line bundles; detection is informational only, hosts are
// allowed to deviate as long as their prebuild output still builds.
const RN_BY_SDK = { 56: '0.85', 57: '0.86', 58: '0.88' };

const NEXT_STEPS = [
  '  1. Declare the plugin in app.json:',
  '',
  '       "plugins": ["@fishmeet/rn-sdk"]',
  '',
  '     The plugin applies every native entry automatically: the LiveKit/WebRTC',
  '     setup, the Android PiP manifest flag + MainActivity overrides + R8 rules',
  '     for the WebRTC JNI stub, and the iOS UIBackgroundModes audio entry.',
  '',
  '  2. Re-run the native build:  npx expo prebuild   (or expo run:ios / run:android)',
  '',
  '  3. Optional props on <FishMeet />:',
  '     - onEnterPictureInPicture: called on the PiP toggle press; return false to',
  '       keep the meeting in-app (e.g. your own floating window).',
  '     - inPictureInPicture: renders the PiP-compact meeting UI (stage only) for',
  '       host-driven small windows.',
  '',
];

const STATIC_NOTES = [
  'Notes:',
  '  - Tested baseline: Expo SDK 58 / RN 0.88. SDK 56 / 57 are supported by',
  '    peer range and API audit only, not runtime-tested.',
  '  - @livekit/react-native and @livekit/react-native-webrtc are paired:',
  '    2.12.x <-> 144.x, 3.1.x <-> 150.x. Mixing the pairs compiles but crashes',
  '    on iOS at runtime.',
  '  - WebRTC 150 is the android-prefixed build: native symbols moved from',
  '    org.webrtc.* to livekit.org.webrtc.*; host native code that imports the',
  '    old package must migrate.',
  '  - Android release builds need -dontwarn livekit.org.jni_zero.**; the config',
  '    plugin injects it during prebuild.',
];

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_error) {
    return null;
  }
}

function selfVersion() {
  const pkg = readJson(path.join(__dirname, '..', '..', 'package.json'));
  return pkg && typeof pkg.version === 'string' ? pkg.version : 'unknown';
}

// INIT_CWD is set by npm / yarn / pnpm to the directory the install was run
// from; cwd is the fallback for direct execution during development.
function findHostRoot() {
  const starts = [];
  if (process.env.INIT_CWD) {
    starts.push(process.env.INIT_CWD);
  }
  starts.push(process.cwd());
  for (const start of starts) {
    let dir = start;
    for (let depth = 0; depth < 4; depth += 1) {
      if (readJson(path.join(dir, 'package.json'))) {
        return dir;
      }
      const parent = path.dirname(dir);
      if (parent === dir) {
        break;
      }
      dir = parent;
    }
  }
  return null;
}

function parseVersion(value) {
  if (typeof value !== 'string') {
    return null;
  }
  const three = value.match(/(\d+)\.(\d+)\.(\d+)/);
  if (three) {
    return { major: Number(three[1]), minor: Number(three[2]), patch: Number(three[3]) };
  }
  const one = value.match(/(\d+)/);
  return one ? { major: Number(one[1]), minor: -1, patch: -1 } : null;
}

// Walks up from the host root so hoisted / workspace layouts resolve, then
// degrades to the declared range when node_modules is absent (pnpm 10 blocks
// lifecycle scripts, global installs, ...).
function detectVersion(root, name) {
  let dir = root;
  for (let depth = 0; depth < 6; depth += 1) {
    const pkg = readJson(path.join(dir, 'node_modules', ...name.split('/'), 'package.json'));
    if (pkg && typeof pkg.version === 'string') {
      return { raw: pkg.version, parsed: parseVersion(pkg.version), source: 'installed' };
    }
    const parent = path.dirname(dir);
    if (parent === dir) {
      break;
    }
    dir = parent;
  }
  const manifest = readJson(path.join(root, 'package.json')) || {};
  const declared =
    (manifest.dependencies && manifest.dependencies[name]) ||
    (manifest.devDependencies && manifest.devDependencies[name]) ||
    (manifest.peerDependencies && manifest.peerDependencies[name]);
  if (typeof declared === 'string') {
    return { raw: declared, parsed: parseVersion(declared), source: 'declared' };
  }
  return null;
}

// Only the rules that a single peer range cannot express; a full peer walk
// would just repeat the package manager's own warnings.
function rangeSatisfied(name, parsed, expoMajor) {
  if (!parsed) {
    return null;
  }
  switch (name) {
    case 'expo':
      return parsed.major >= 56;
    case 'react-native':
      return parsed.major === 0 && parsed.minor >= 85;
    case '@livekit/react-native':
      return (parsed.major === 2 && parsed.minor >= 12) || (parsed.major === 3 && parsed.minor >= 1);
    case '@livekit/react-native-webrtc':
      return parsed.major === 144 || parsed.major === 150;
    default:
      return expoMajor === null ? null : parsed.major === expoMajor;
  }
}

function rawOf(entry) {
  return entry ? entry.raw : 'missing';
}

function collectWarnings(detected) {
  const warnings = [];
  const expo = detected.expo && detected.expo.parsed;
  const lk = detected['@livekit/react-native'] && detected['@livekit/react-native'].parsed;
  const webrtc = detected['@livekit/react-native-webrtc'] && detected['@livekit/react-native-webrtc'].parsed;

  // Missing native peers are the one case a peer warning undersells: without
  // them the SDK has no WebRTC bindings to link at all.
  if (!detected['@livekit/react-native']) {
    warnings.push('missing peer @livekit/react-native — install it in the host app (native module).');
  }
  if (!detected['@livekit/react-native-webrtc']) {
    warnings.push('missing peer @livekit/react-native-webrtc — install it in the host app (native module).');
  }

  if (lk && webrtc) {
    if (lk.major === 2 && webrtc.major !== 144) {
      warnings.push(
        `@livekit/react-native ${rawOf(detected['@livekit/react-native'])} must pair with @livekit/react-native-webrtc 144.x (found ${rawOf(detected['@livekit/react-native-webrtc'])}): 3.x needs 150.x and mixing them crashes on iOS.`,
      );
    }
    if (lk.major === 3 && webrtc.major !== 150) {
      warnings.push(
        `@livekit/react-native ${rawOf(detected['@livekit/react-native'])} must pair with @livekit/react-native-webrtc 150.x (found ${rawOf(detected['@livekit/react-native-webrtc'])}): 2.12 needs 144.x and mixing them crashes on iOS.`,
      );
    }
  }

  // AGP 9 (Expo 58) registers the kotlin extension itself; 2.x and 3.0 apply
  // kotlin-android unconditionally and abort Gradle configuration.
  if (expo && expo.major >= 58 && lk && lk.major === 2) {
    warnings.push(
      `Expo ${rawOf(detected.expo)} + Android requires @livekit/react-native ^3.1.0 (found ${rawOf(detected['@livekit/react-native'])}): 2.x applies kotlin-android unconditionally and fails on AGP 9.`,
    );
  }
  if (expo && expo.major >= 58 && lk && lk.major === 3 && lk.minor >= 0 && lk.minor < 1) {
    warnings.push(
      `@livekit/react-native ${rawOf(detected['@livekit/react-native'])} applies kotlin-android unconditionally; use ^3.1.0 on Expo 58 Android.`,
    );
  }

  // Native Expo module packages are built against a specific SDK line.
  if (expo && SDK_LINES[expo.major]) {
    const expected = SDK_LINES[expo.major];
    for (const name of Object.keys(expected)) {
      const entry = detected[name];
      if (entry && entry.parsed && entry.parsed.major !== expo.major) {
        warnings.push(`${name} ${entry.raw} does not follow Expo SDK ${expo.major}; install ${expected[name]}.`);
      }
    }
  }

  return warnings;
}

function rnLineNote(detected) {
  const expo = detected.expo && detected.expo.parsed;
  const rn = detected['react-native'] && detected['react-native'].parsed;
  if (!expo || !rn || !RN_BY_SDK[expo.major]) {
    return null;
  }
  const expected = RN_BY_SDK[expo.major];
  const actual = `${rn.major}.${rn.minor}`;
  if (actual === expected) {
    return null;
  }
  return `expo ${rawOf(detected.expo)} bundles react-native ${expected}.x (detected ${actual}.x); verify the prebuild output if this is intentional.`;
}

function statusOf(name, entry, expoMajor) {
  if (!entry || !entry.parsed) {
    return 'unknown';
  }
  const satisfied = rangeSatisfied(name, entry.parsed, expoMajor);
  return satisfied ? 'ok' : 'MISMATCH';
}

function row(label, version, range, status) {
  const cells = [label.padEnd(32), version.padEnd(22), range.padEnd(34), status];
  return `  ${cells.join('')}`;
}

function compatibilityBlock(root, detected) {
  const expo = detected.expo && detected.expo.parsed;
  const expoMajor = expo ? expo.major : null;
  const lk = detected['@livekit/react-native'] && detected['@livekit/react-native'].parsed;
  const webrtc = detected['@livekit/react-native-webrtc'] && detected['@livekit/react-native-webrtc'].parsed;
  // Peer ranges accept both WebRTC majors, so a wrong pair still reads "ok"
  // there; mark the row so the table cannot contradict the WARNINGS block.
  const pairConflict =
    (lk && webrtc && lk.major === 2 && webrtc.major !== 144) ||
    (lk && webrtc && lk.major === 3 && webrtc.major !== 150);

  const lines = [`Compatibility (detected from ${root}):`];

  for (const pkg of PACKAGES) {
    const entry = detected[pkg.name];
    let status = statusOf(pkg.name, entry, expoMajor);
    if (pairConflict && pkg.name === '@livekit/react-native-webrtc') {
      status = 'MISMATCH (pair)';
    }
    lines.push(row(pkg.name, entry ? entry.raw : '-', `peer ${pkg.range}`, status));
  }

  const subs = ['expo-blur', 'expo-audio', 'expo-keep-awake'];
  const present = subs.filter((name) => detected[name]);
  if (present.length > 0) {
    const versions = present.map((name) => detected[name].raw).join('/');
    const statuses = present.map((name) => statusOf(name, detected[name], expoMajor));
    const status = statuses.includes('MISMATCH') ? 'MISMATCH' : statuses.includes('unknown') ? 'unknown' : 'ok';
    lines.push(row('expo-blur/audio/keep-awake', versions, 'peer ~56 || ~57 || ~58', status));
  }

  const declared = Object.keys(detected).filter((name) => detected[name].source === 'declared');
  if (declared.length > 0) {
    lines.push('', `  versions marked from package.json ranges (node_modules not readable): ${declared.join(', ')}`);
  }

  const note = rnLineNote(detected);
  if (note) {
    lines.push('', `  note: ${note}`);
  }

  return lines;
}

function main() {
  const lines = ['', `fishmeet: @fishmeet/rn-sdk ${selfVersion()} installed.`, ''];

  let detected = {};
  let root = null;
  let checked = false;
  try {
    root = findHostRoot();
    if (root) {
      for (const pkg of PACKAGES) {
        const entry = detectVersion(root, pkg.name);
        if (entry) {
          detected[pkg.name] = entry;
        }
      }
      for (const name of ['expo-blur', 'expo-audio', 'expo-keep-awake']) {
        const entry = detectVersion(root, name);
        if (entry) {
          detected[name] = entry;
        }
      }
      // Without expo or react-native this is not a host app (global install,
      // temp extraction, ...); reporting missing peers there would be noise.
      checked = Boolean(detected.expo || detected['react-native']);
    }
  } catch (_error) {
    detected = {};
    root = null;
    checked = false;
  }

  let warnings = [];
  if (checked) {
    try {
      warnings = collectWarnings(detected);
    } catch (_error) {
      warnings = [];
    }
  }

  if (warnings.length > 0) {
    lines.push('WARNINGS');
    for (const warning of warnings) {
      lines.push(`  ! ${warning}`);
    }
    lines.push('');
  }

  lines.push('Next steps:', ...NEXT_STEPS);

  if (checked) {
    lines.push(...compatibilityBlock(root, detected), '');
  } else if (root) {
    lines.push(`Compatibility: not checked (no Expo / React Native project detected at ${root}).`, '');
  } else {
    lines.push('Compatibility: not checked (host package.json not found).', '');
  }

  lines.push(...STATIC_NOTES, '');

  console.log(lines.join('\n'));
}

main();
